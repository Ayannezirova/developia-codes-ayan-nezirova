package az.developia.springwebayann;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringwebAyannApplicationTests {

	@Test
	void contextLoads() {
	}

}
