package Developia.spring.web.MVC.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringwebAyaanApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringwebAyaanApplication.class, args);
	}

}
