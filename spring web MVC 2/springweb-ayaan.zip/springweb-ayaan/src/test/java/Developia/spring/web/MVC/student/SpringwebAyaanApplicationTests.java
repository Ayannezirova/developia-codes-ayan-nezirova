package Developia.spring.web.MVC.student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringwebAyaanApplicationTests {

	@Test
	void contextLoads() {
	}

}
