package az.developia.springjpaayaan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaAyaanApplicationTests {

	@Test
	void contextLoads() {
	}

}
