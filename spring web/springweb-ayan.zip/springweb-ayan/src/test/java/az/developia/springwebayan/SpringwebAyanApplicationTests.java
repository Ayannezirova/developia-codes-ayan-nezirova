package az.developia.springwebayan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringwebAyanApplicationTests {

	@Test
	void contextLoads() {
	}

}
